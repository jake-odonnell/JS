function city(){
    alert("Loading Weather Report...")
}

function accept(el){
    console.log('hi')
    el.parentNode.remove()
}

var todaymax = document.querySelector('#todaymax')
var todaymin = document.querySelector('#todaymin')
var tomorrowmax = document.querySelector('#tomorrowmax')
var tomorrowmin = document.querySelector('#tomorrowmin')
var fridaymax = document.querySelector('#fridaymax')
var fridaymin = document.querySelector('#fridaymin')
var saturdaymax = document.querySelector('#saturdaymax')
var saturdaymin = document.querySelector('#saturdaymin')

function convert(unit){
    todaymax.innerText = '75'+'\xB0'
    todaymin.innerText =   '64'+'\xB0'
    tomorrowmax.innerText =  '80'+'\xB0'
    tomorrowmin.innerText =  '66'+'\xB0'
    fridaymax.innerText =  '70'+'\xB0'
    fridaymin.innerText =  '61'+'\xB0'
    saturdaymax.innerText =  '79'+'\xB0'
    saturdaymin.innerText =  '70'+'\xB0'
}
